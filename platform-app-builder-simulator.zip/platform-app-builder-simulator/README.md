# Platform App Builder Practice Simulator

Self-contained simulator generated from the supplied `Plat-Admn-202 2.pdf`.

## Use
1. Open `index.html` in any modern browser.
2. Study all 259 questions or a smaller block.
3. Use Exam Mode for 60 random questions / 105 minutes / 63% practice target.
4. Progress is stored locally in the browser with `localStorage`.

## GitHub Pages
Upload `index.html` to a GitHub repository, then enable **Settings → Pages → Deploy from a branch**.

No build step or external dependencies are required.
